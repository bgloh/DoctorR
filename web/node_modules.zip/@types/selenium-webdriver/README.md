# Installation
> `npm install --save @types/selenium-webdriver`

# Summary
This package contains type definitions for Selenium WebDriverJS 2.53.1 (https://github.com/SeleniumHQ/selenium/tree/master/javascript/node/selenium-webdriver).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/selenium-webdriver

Additional Details
 * Last updated: Fri, 07 Oct 2016 17:35:57 GMT
 * File structure: MultipleModules
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: chrome, edge, executors, firefox, http, ie, opera, remote, safari, testing, webdriver

# Credits
These definitions were written by Bill Armstrong <https://github.com/BillArmstrong>, Yuki Kokubun <https://github.com/Kuniwak>, Craig Nishina <https://github.com/cnishina>.
